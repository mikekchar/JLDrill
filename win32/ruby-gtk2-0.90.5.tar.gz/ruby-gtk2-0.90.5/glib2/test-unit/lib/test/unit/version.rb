
# HACK: quick and dirty to get integrated into the new project - ryan
module Test
  module Unit
    VERSION = '2.1.2'
  end
end
